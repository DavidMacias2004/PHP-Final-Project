<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include("php/header.php")?>
    <main>
        <br>
        <h2 id="contact_h2">How to Reach Us</h2>
        <ul id="contact_ul">
            <li>
                Phone: 770-549-8563
            </li>
            <li>
                Email: davidmaciasmorales1@gmail.com
            </li>
            <li>
                Alternate Email: d.maciasmorales2004@gmail.com
            </li>
    </main>
    <footer>
        <p>
            David Macias Morales, 10/15/2023
            <br>
            Contact us <a href="contact.html">here!</a>
        </p>
    </footer>
</body>
</html>