<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include("php/header.php")?>
    <main>
        <section>
            <br>
            <h2 style="text-align: center;">Essential Camping Tool Reccomendations</h2>
            <p>These are just a few tools that you can buy to get straight to camping. It is important, however,
                to do your own research to find tools that are best for you. Take cost, quality
                and other people's experiences with the product into consideration when searching.
            </p>
        </section>
        <section class="events">
            <div class="events">
                <img class="events" alt="Tent" src="images/tent.jpg">
                <a target="_blank" href="https://www.dickssportinggoods.com/p/quest-switchback-8-person-cross-vent-dome-tent-21queu8pcrssvnttncat/21queu8pcrssvnttncat?sku=22098000&camp=CSE:DSG_92700077017219146_pla_pla-2107321839353_58700008079349751_71700000101024692&segment=&gad_source=1&gclid=CjwKCAiA9ourBhAVEiwA3L5RFnT31UY7zyeHb6IiI7pxs-0IbBanfT4m0j8UPPcW1WKQGIf3elWA3hoCnaoQAvD_BwE&gclsrc=aw.ds">
                    <h2>$59.99 Camping Dome Tent</h2>
                </a>
                <p>
                    Essential tent that can fit up to 8 people! This spatious tent can be found on Dick's Sporting Goods for $59.99.
                </p>
                <br>
                <ul class="events">
                    <li>112 sq. ft.</li>
                    <li>8 Person Tent</li>
                    <li>Water-resistent</li>
                </ul>
            </div>
            <div class="events">
                <img class="events" alt="Sleeping Bag" src="images/sleepingbag.jpg">
                <a target="_blank" href="https://www.academy.com/p/magellan-outdoors-rectangle-sleeping-bag-108856716?sku=blue-45-degrees&gmc_feed=t&&ogmap=SEM%7cPLN%7cGOOG%7cSHOP%7cc%7cOUT%7cIM%7cNon-Brand-PerformanceMax-Outdoor-Camping%7cCamping%7c%7c18347843469%7c0&gad_source=1&gclid=CjwKCAiA9ourBhAVEiwA3L5RFkQjVMXs1YAXuuMFyLPTfeUujNLs016z19BRsbco-KcJ4oxvnGcHjBoC6PsQAvD_BwE&gclsrc=aw.ds">
                    <h2>$9.99 Sleeping Bag</h2>
                </a>
                <p>
                    A good quality sleeping bag for an amazing price, this sleeping bag is sure to make
                    not only your back happy, but your wallet as well. Priced at $9.99, this bag can be found on Dick's Sporting Goods.
                </p>
                <ul class="events">
                    <li>Inexpensive</li>
                    <li>4.6 Star Reviews</li>
                    <li></li>
                </ul>
            </div>
            <div class="events">
                <img class="events" alt="4-pack Lanterns" src="images/lanterns.jpg">
                <a target="_blank" href="https://www.amazon.com/Collapsible-XTAUTO-Lightweight-Waterproof-Rechargeable/dp/B0915B6X66/ref=asc_df_B0915B6X66/?tag=hyprod-20&linkCode=df0&hvadid=507808891678&hvpos=&hvnetw=g&hvrand=8525185253246514590&hvpone=&hvptwo=&hvqmt=&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=9010889&hvtargid=pla-1297697308457&mcid=eec42b088c303b0590b464accc5ed318&gclid=CjwKCAiA9ourBhAVEiwA3L5RFs62lNE9Nkm41iVAam8ek1lnXZArlgRyJfyBOwBxK-wrOvx31rxnkhoChQcQAvD_BwE&th=1">
                    <h2>$19.59 4-Pack Lantern set</h2>
                </a>
                <p>
                    These lanterns are good quality, affordable, and there are enough for each memnber
                    of a small family! This great set can be found on Amazon for $19.59.
                </p>
                <ul class="events">
                    <li>LED Bulbs</li>
                    <li>25 Hour Battery life</li>
                    <li>Rechargable</li>
                </ul>
            </div>
        </section>
        <br>
    </main>
    <footer>
        <p>
            David Macias Morales, 10/15/2023
            <br>
            Contact us <a href="contact.html">here!</a>
        </p>
    </footer>
</body>
</html>