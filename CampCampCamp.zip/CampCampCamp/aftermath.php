<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include("php/header.php")?>
    <main>
        <section>
            <br>
            <h2>The Aftermath</h2>
            <img class="right-img" height="200px" src="/images/cleaning.jpg">
            <p>What do you do afterwards? Clean up after yourself and remember the “Leave No Trace” principles. The campsite should look the exact same as it did when you first got there. After you leave it should seem like no one ever occupied this spot to begin with. Throw away all your trash and recycle whatever you can.</p>
        </section>
        <br>
        <br>
        <br>
        <h3 id="about_h3">Good Job!! You’ve successfully survived your first ever camping expedition!</h3>
    </main>
    <footer>
        <p>
            David Macias Morales, 10/15/2023
            <br>
            Contact us <a href="contact.html">here!</a>
        </p>
    </footer>
</body>
</html>