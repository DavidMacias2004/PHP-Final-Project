<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CampCamp Campsites</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include("php/header.php")?>
    <main>
        <br>
        <section>
            <h2>
            Home Page!
            </h2>
            <img class="right-img" height="200px" alt="Campsite" src="https://live.staticflickr.com/8318/7937856636_30afd50a5d_b.jpg">
            <p>
                Spending a day in the wilderness may seem daunting, but it's one of the most relaxing things in the world! Having the ability to be alone with your own thoughts, accompanied by the sounds of moving water, chirping birds, and the blowing wind, is an incredibly stress relieving activity. Here at CampCamp Campsites, we will teach you how to properly enjoy Mother Nature at her fullest, and safely too.
            </p>
            <p>
                We have plenty of webpages to help you out. Some include:
            </p>
            <ul id="index_ul">
                <li>How to Camp - The place for various basic rules and tips, as well as detailed guides to get you started</li>
                <li>Camping Tools - a page filled with necessary or helpful tools for you camping endeavors</li>
                <li>Events - your go-to page for various local events</li>
            </ul>
        </section>

        <img id="divider" src="images/divider.png">
        
        <section>
            <div class="cubes">
                <a href="events.html">
                    <div class="cube-block">
                        <img class="right-img" style="width: 30%;" height="200px" alt="Events" src="https://upload.wikimedia.org/wikipedia/commons/a/a9/Camping_at_night.jpg">
                        <div class="text-block1">
                            <h4>Events</h4>
                            <p>Current Camp Events</p>
                        </div>
                    </div>
                </a>
                <a href="campingTools.html">
                    <div class="cube-block">
                        <img class="right-img" style="width: 30%;" height="200px" alt="Camping Tools" src="https://live.staticflickr.com/1163/542927498_cec2346217_b.jpg">
                        <div class="text-block2">
                            <h4>Camping Tools</h4>
                            <p>Recommended Camping Tools</p>
                        </div>
                    </div>
                </a>
                <a href="how2camp.html">
                    <div class="cube-block">
                        <img class="right-img" style="width: 30%;" height="200px" alt="How to Camp" src="https://live.staticflickr.com/8291/7727737944_996a8edebc_b.jpg">
                        <div class="text-block3">
                            <h4>How to Camp</h4>
                            <p>Camping Guides</p>
                        </div>
                    </div>
                </a>
            </div>
        </section>
        <sectionc class="section1">
            <br>
            <h2>Reach out to us!</h2>
            <p>
                If you'd like to reach out to the owner of the website, head over to the <a href="about.html">About</a> page! There you can find multiple ways to contact the owner if there's ever a need to.
            </p>
            <br>
        </section>
    </main>
    <footer>
        <p>
            David Macias Morales, 10/15/2023
            <br>
            Contact us <a href="contact.html">here!</a>
        </p>
    </footer>
</body>
</html>
