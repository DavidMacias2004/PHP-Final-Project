<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include("php/header.php")?>
    <main>
        <br>
        <h2>How to Camp</h2>
        <p>This page is an all around guide to camping! Here we’ll teach you what to do before you start, during the camping experience, and what to do after it's all said and done.</p>
        <section>
            <div class="cubes">
                <a href="aftermath.html">
                    <div class="cube-block">
                        <img class="right-img" style="width: 30%;" height="200px" alt="Events" src="images/cleaning.jpg">
                        <div class="text-block1">
                            <h4>The Aftermath</h4>
                            <p>What's Next?</p>
                        </div>
                    </div>
                </a>
                <a href="camping.html">
                    <div class="cube-block">
                        <img class="right-img" style="width: 30%;" height="200px" alt="Camping Tools" src="images/photography.jpg">
                        <div class="text-block2">
                            <h4>Actually Camping</h4>
                            <p>Tips for while you're Camping</p>
                        </div>
                    </div>
                </a>
                <a href="beforeyourtrip.html">
                    <div class="cube-block">
                        <img class="right-img" style="width: 30%;" height="200px" alt="How to Camp" src="images/planning.jpg">
                        <div class="text-block3">
                            <h4>Before Your Trip</h4>
                            <p>What to do before your Adventure</p>
                        </div>
                    </div>
                </a>
            </div>
        </section>
        <br>
        <section>
            <p>While these guides are great, be sure to read the rules and regulations of the campsite you decide to visit. Different organizations have different rules or recommendations regarding what gear to bring, what kind of food to bring, and other things of that nature.</p>
            <p>If at all possible, please bring a friend that has experience in camping.</p>
            <img id="divider" src="images/divider.png">
            <p>Consider visiting the <a href="campingTools.html">Camping Tools</a> webpage to get a few recommendations on well-priced, quality camping gear!</p>
        </section>
    </main>
    <footer>
        <p>
            David Macias Morales, 10/15/2023
            <br>
            Contact us <a href="contact.html">here!</a>
        </p>
    </footer>
</body>
</html>