<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include("php/header.php")?>
    <main>
        <br>
        <h2>We’re here!.. Now what?</h1>
        <br>
        <p>Congratulations! You’re officially camping for the first time ever! Now what do you do? Here's a list of activities you can enjoy while you're out and about.</p>
        <img class="right-img" src="images/photography.jpg" height="190px">
        <ul class="camplists">
            <li>Bonfires</li>
            <li>Watching the wildlife</li>
            <li>Sleeping under the stars</li>
            <li>Photography</li>
            <li>Fishing</li>
            <li>Canoeing</li>
        </ul>
        <p>To attend any current/ongoing events, feel free to visit the <a href="events.html">Event Page!</a></p>
        <br>
        <img id="divider" src="images/divider.png">
        <br>
        <section>
            <h2>What about Food?</h2>
        <p>While all these activities are nice and fun, what do we do for food? While thinking about it, keep these things in mind:</p>
        <ul class="camplists">
            <li>Eat whatever spoils the fastest first - anything like meat or dairy products should be consumed first as you don’t want them to spoil. Spoiled food is bad for a variety of reasons but the main concern is food poisoning. Having food poisoning while you're out in the wild is very dangerous and could lead to serious health concerns.</li>
            <li>Smells = Bad - Any food that has an odor potent enough to attract wildlife is an absolute no-go, especially if you're in an area with bears. Even though it’s not technically forbidden, it is an incredibly bad idea.</li>
            <li>Foods that require less tools to make are preferred, as it makes cleaning up the mess way easier.</li>
            <li>Storing - Store your food in well guarded, hard to get to places. Some campsites have bear boxes for food storage, to ensure there is no odor produced and no bears steal your food.</li>
            <li>Clean up any leftover food or residue after you’re done eating. Not only is this good camping etiquette, but it means there’ll be fewer animals to worry about later on.</li>
        </ul>
        </section>
        <img id="divider" src="images/divider.png">
        <br>
        <section>
            <h2>Camping Etiquette</h2>
            <p>Here are a few general rules you'll want to follow if you don’t want other campers to hate you!</p>
            <h3 id="about_h3">Shhh… Quiet</h3>
            <p>Many campsites have “quiet hours” that you must follow. During this period, keep quiet as others are either sleeping or just trying to relax and enjoy nature’s music. Do keep in mind, though, that even though quiet hours do end, that doesn’t mean you should be as loud as you want! Not only is that a danger to you, it’s also very annoying for your peers. The same could be said about your lights. Keep them off or low during those quiet hours.</p>
            <h3 id="about_h3">Be Mindful of Other People's No-No Squares!</h3>
            <p>Keeping to your area is a very respectful thing to do. Not much else to it.</p>
            <h3 id="about_h3">Stay clean!</h3>
            <p>Keep your area - and yourself - clean. Do this to keep pests away and to set a good example for those camping alongside you. Even though its not a rule, keep yourself clean, for your sake and for the sake of others.</p>
        </section>
        <br>
    </main>
    <footer>
        <p>
            David Macias Morales, 10/15/2023
            <br>
            Contact us <a href="contact.html">here!</a>
        </p>
    </footer>
</body>
</html>