<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include("php/header.php")?>

    <main>
        <br>
        <h1 style="text-align: center; padding: 20px 0;">
            About Us
        </h1>
        <h3 id="about_h3">"We're here to make your camp life easier."</h3>
        <br>
        <img id="about_img" style="width: 50%;" alt="Helping You Hike" src="https://live.staticflickr.com/1796/42172615510_26291ea524_b.jpg">
        <br>
        <br>
        <p class="">
            Here at CCC, we strive to assist clientele who struggle with knowledge (or the lack thereof) in the field of camping, road tips, and RV maintenance. Our goal is to ensure each and every person who visits any campsite leaves with a better understanding of camping than they had when they first appeared.
        </p>
        <p>
            Making this website has been a ton of fun for our company and we are happy to have an outlet
            to push out our campsites and teach new people how to camp safely!
            Our How to Camp guide was made with extensive research behind each and every point made.
            We used the official National Park Service website as reference and we will give much credit
            to their hard work. 
        </p>
        <p>
            If there is anyone with any questions, feel free to contact us <a href="contact.html">here.</a>
            We will respond within a timely manner and will do extensive research before responding 
            to any question presented.
        </p>
        <br>
    </main>
    <footer>
        <p>
            David Macias Morales, 10/15/2023
            <br>
            Contact us <a href="contact.html">here!</a>
        </p>
    </footer>
</body>
</html>