<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include("php/header.php")?>
    <main>
        <br>
        <h2>Before Your Trip!</h2>
        <p>Camping may be a fun activity but always prepare adequately or else you could put yourself or someone you love in danger.</p>
        <br>
        <section>
            <h2>Planning Your Trip</h2>
            <p>Plan the time of the year, the place you want to camp at, and how long you want to stay there for.</p>
            <img class="right-img" src="images/planning.jpg" height="200px">
            <ul class="camplists">
                <li>Selecting a place: Use a reliable website to search for a campsite that’s within a reasonable difficulty level for you.</li>
                <li>Selecting a Time: Camping can vary in difficulty depending on what time of the year you go in; whether it’s the blaring heat of the summer or painful colds of the winter, the equipment you’ll want to bring will vary.</li>
                <li>How long you’ll stay: The duration of your stay will ultimately decide how much gear and resources you’ll need to bring.</li>
            </ul>
            <p>Sometimes certain campsites will have different rules and regulations, so be sure to read all of them thoroughly to ensure, not only your safety, but the safety of others.</p>
        </section>
        <br>
        <img id="divider" src="images/divider.png">
        <section>
            <h2>What to Bring</h2>
            <p>One of the most important things about camping is the gear you take with you. Here is a list of items that you’ll definitely need.</p>
            <img class="right-img" src="images/camping_gear.jpg" height="200px">
            <ul class="camplists">
                <li>Food and water -  Make sure to bring enough water to last you your entire stay AND THEN SOME. This is very important. It cannot be stressed enough. Bring extra food and water, since you’ll never know when it’ll accidentally get dropped in the mud, wild animals decide to be devious, or if tragedy strikes. Bring plenty of cooking supplies like knives, camping stoves, silverware, plates; things of that nature.</li>
                <li>Shelter - Bring tents, sleeping bags, sleeping pads, pillows; anything that’ll make your sleep more comfortable. A good night's rest is essential when camping in the wilderness. If you’re camping in an area with a colder climate, be sure to bring thick bedding.</li>
                <img class="left-img" src="images/navigation.webp" height="200px" width="280px" style="float: left;">
                <li>Personal care products - Washcloths, bars of soaps, toothbrushes, floss, and feminine hygiene products are quite important if you’re trying to stay clean while at the mercy of mother nature. First aid kits are especially important. Plenty of bug spray and sun protection also helps if you're trying to stay comfortable.</li>
                <li>Navigation - Bring a map or GPS. Do not get lost in the woods, it's never a good time. Also bring a flashlight or a lantern.</li>
            </ul>
            <p>One thing that people might overlook is how the outside world will find you if something goes wrong. Bring a personal locator beacon in case your cell phone doesn't have service, or in case the battery dies.</p>
            <p>After ensuring that all your gear is working up to par, it’s time to set off!</p>
        </section>
    </main>
    <footer>
        <p>
            David Macias Morales, 10/15/2023
            <br>
            Contact us <a href="contact.html">here!</a>
        </p>
    </footer>
</body>
</html>