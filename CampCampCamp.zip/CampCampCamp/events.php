<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include("php/header.php")?>
    <main>
        <section>
            <br>
            <h2>
            Event Page!
            </h2>
            <p>
                Don't have anyone to camp with? No worries! Here are some perfect 
                public events for you to hang out with people you would have never 
                met otherwise. These events range from nice church events to large 
                get togethers with strangers.
            </p>
        </section>
        <br>
        <section class="events">
            <div class="events">
                <img class="events" alt="Bonfire" src="images/bonfire.jpg">
                <h2>Monthly Bonfire Event: Everyone's Welcome</h2>
                <p>
                    November's Bonfire Event where everyone is welcome! 
                    Beginner campers are allowed and encouraged to come!
                    Free fun for the whole family.
                </p>
                <br>
                <ul class="events">
                    <li>Free food</li>
                    <li>Tents are NOT provided</li>
                    <li>Kids welcome!</li>
                </ul>
            </div>
            <div class="events">
                <img class="events" alt="Karaoke" src="images/karaoke.jpg">
                <h2>Karaoke Night: Singing with the Stars</h2>
                <p>
                    No songs are off limits. Will get hectic but will also be a blast! Strangers are welcome.
                    No need to stay the night but tents will be provided to those who do (first come first serve).
                </p>
                <ul class="events">
                    <li>Free food</li>
                    <li>Tents are provided</li>
                    <li>Not kid friendly!</li>
                </ul>
            </div>
            <div class="events">
                <img class="events" alt="Fishing" src="images/fishing.jpg">
                <h2>Fishing Tournament: The Trout Championship</h2>
                <p>
                    In this free for all tournament, whoever reels in the largest fish will win a cash prize of $1,000!
                    Participents from all types of experience are welcome to join.
                </p>
                <ul class="events">
                    <li>Bring your own rod</li>
                    <li>Cash Prize</li>
                    <li>Age requirement: 13+</li>
                </ul>
            </div>
            <div class="events">
                <img class="events" alt="Painting" src="images/painting.jpeg">
                <h2>Let's Paint the Stars</h2>
                <p>
                    Bring out your inner Van Gogh and paint the beautiful scenary of one of CampCamp's
                    beautiful Campsites. We bring the materials, you bring the skill.
                </p>
                <br>
                <ul class="events">
                    <li>Art supplies are provided</li>
                    <li>Sponsored by CampCamp</li>
                </ul>
            </div>
        </section>
    </main>
    <footer>
        <p>
            David Macias Morales, 10/15/2023
            <br>
            Contact us <a href="contact.html">here!</a>
        </p>
    </footer>
</body>
</html>